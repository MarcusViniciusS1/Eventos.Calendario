package com.eventos.calendario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalendarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
